#Sentiment analysis project that extracts data from Twitter to get an idea of whether the general sentiment of a topic is positive, negative or neutral

# #INSTALLS NECESSARY PACKAGES
# installed.package(hms);installed.package(lubridate);installed.package(tidytext);installed.package(tm);installed.package(wordcloud);installed.package(igraph);
# installed.package(glue);installed.package(networkD3);installed.package(rtweet);installed.package(plyr);installed.package(stringr);installed.package(ggplot2);
# installed.package(ggeasy);installed.package(plotly);installed.package(dplyr);installed.package(magrittr);installed.package(tidyverse);installed.package(emoji);
# install.packages(sjmisc)


#Run each library to make sure they're loaded into R 
library(hms);library(lubridate);library(tidytext);library(tm);library(wordcloud);library(igraph);library(glue);library(networkD3);
library(rtweet);library(plyr);library(stringr);library(ggplot2);library(ggeasy);library(plotly);library(dplyr);library(magrittr);
library(tidyverse);library(emoji);library(sjmisc)

## IMPORTANT TO SET WORKING DIRECTORY FOR WHEN THE PROGRAM TRIES TO WRITE OR IMPORT DATA TO/FROM THE DIRECTORY
setwd("~/ECO365 Final project")


#########################################################################################################################################################
#########################################################################################################################################################


#Critical info for api usage 
#consumerKey <- 'crmDgm1TgLBQEBVSjYHUBakoS'
#consumerSecret <-'AyjEZYfZTIPZR8ftWkAin9YAdYfJQawesI2Ffp1HgOPrm6mxay'
#bearerToken <-"AAAAAAAAAAAAAAAAAAAAAL0%2FjAEAAAAAGOPUI11ee2uBv9GM73lK%2Fg69hyY%3DuyuTf4g77jf7bOyYqDnXaxBWRMdFRMRrv71qeUW1WrWS14SQox"
#accessToken <- '1584948943494041601-7LknBxGNdWZz58TCPc4SbfBJpdeQc8'
#accessTokenSecret <- 'PouZfyimd7YlWEDNLH6xvuB6NddolxOjMHDjRA8VIB0WI'
#client_ID <- "WnBxRWV0MjBUbGNQOW95eVA4U2w6MTpjaQ"
#clientSecret <- "WD5Z4vxV-z28kgQ_-XE1LvZu2CHSQtRQr_sprT32QnuVA4jaay"


#########################################################################################################################################################
#########################################################################################################################################################

###CODE DOES NOT WORK AS INTENDED, SAVED AS COMMENT TO COME BACK TO LATER
###ATTEMPTING TO PULL MORE DATA FROM TWITTER PAST THE CURRENT LIMITATION OF 6 - 9 DAYS

#bearer_token <- Sys.setenv(BEARER_TOKEN = bearerToken)
#headers <- c(`Authorization` = sprintf('Bearer %s', bearer_token))


#tweets2<- search_30day(
 # q= '#NationalGrid',
#  n = 4000,
#  env_name = "practice",
#  toDate = 202210281200
#  )

#Authenticates the API
#cred <-OAuthFactory$new(consumerKey = 'crmDgm1TgLBQEBVSjYHUBakoS',
#                         consumerSecret = 'AyjEZYfZTIPZR8ftWkAin9YAdYfJQawesI2Ffp1HgOPrm6mxay',
#                        requestURL = 'https://api.twitter.com/auth/request_token',
#                        accessURL = 'https://api.twitter.com/auth/access_token',
#                        authURL = 'https://api.twitter.com/auth/authorize')
#save(cred, file = "twitters authentication.Rdata")
#load("twitters authentication.Rdata")

#my_app <- rtweet_user(consumerKey, consumerSecret)

#auth_as(my_app)
#auth_get()



#########################################################################################################################################################
#########################################################################################################################################################

#FUNCTIONS

#Function to clean tweets and strips them to a dataframe with a single word and its count in each row
cleaned.text = function(text){
  
  words <- tweets %>%
    mutate(text = str_remove_all(text, "&amp;|&lt;|&gt;"),
           text = str_remove_all(text, "\\s?(f|ht)(tp)(s?)(://)([^\\.]*)[\\.|/](\\S*)"),
           text = str_remove_all(text, "[^\x01-\x7F]")) %>% 
    unnest_tokens(word, text, token = "tweets") %>%
    filter(!word %in% stop_words$word,
           !word %in% str_remove_all(stop_words$word, "'"),
           str_detect(word, "[a-z]"),
           !str_detect(word, "^#"),         
           !str_detect(word, "@\\S+")) %>%
       count(word, sort = TRUE)
  
return(words)
}
#########################################################################################################################################################

score.sentiment = function(sentences, pos.words, neg.words, .progress='none')
{
  require(plyr)
  require(stringr)
  
  # we are giving vector of sentences as input. 
  # plyr will handle a list or a vector as an "l" for us
  # we want a simple array of scores back, so we use "l" + "a" + "ply" = laply:
  scores = laply(sentences, function(sentence, pos.words, neg.words) {
    
    # clean up sentences with R's regex-driven global substitute, gsub() function:
    sentence = gsub('https://','',sentence)
    sentence = gsub('http://','',sentence)
    sentence = gsub('[^[:graph:]]', ' ',sentence)
    sentence = gsub('[[:punct:]]', '', sentence)
    sentence = gsub('[[:cntrl:]]', '', sentence)
    sentence = gsub('\\d+', '', sentence)
    sentence = str_replace_all(sentence,"[^[:graph:]]", " ")
    # and convert to lower case:
    sentence = tolower(sentence)
    
    # split into words. str_split is in the stringr package
    word.list = str_split(sentence, '\\s+')
    # sometimes a list() is one level of hierarchy too much
    words = unlist(word.list)
    
    # compare our words to the dictionaries of positive & negative terms
    pos.matches = match(words, pos.words)
    neg.matches = match(words, neg.words)
    
    # match() returns the position of the matched term or NA
    # we just want a TRUE/FALSE:
    pos.matches = !is.na(pos.matches)
    neg.matches = !is.na(neg.matches)
    
    # TRUE/FALSE will be treated as 1/0 by sum():
    score = sum(pos.matches) - sum(neg.matches)
    
    return(score)
  }, pos.words, neg.words, .progress=.progress )
  
  scores.df = data.frame(score=scores, text=sentences)
  return(scores.df)
}

#Call garbage collector to help system memory
gc()
#########################################################################################################################################################
#########################################################################################################################################################


#VARIABLE FOR SEARCH TERM, recommended use is '# ' or string literal " "
trends <- get_trends("United States")

#extracts the trending tweet with the highest volume
maxVol <- trends%>%
  pull(tweet_volume) %>% 
  max(.,na.rm = TRUE)
#extracts the Trending phrase or hashtag and stores into a variable
Lookup <- trends %>% 
  filter(tweet_volume == maxVol) %>% 
  pull(trend)

#Extract up to 18000 tweets, ****NOTE LIMITATION IS 18,000 TWEETS EVERY 15 MINUTES AT CURRENT VERSION
tweets <- search_tweets(Lookup, n = 6000,include_rts = FALSE, type = "recent", lang = "en",fileEncoding = "UTF-8")

#pulls more tweets on same look up from prior to last tweet pulled from previous call USEFUL IF PREVIOUS CALL EXCEEDED THE LIMITATION
tweets2 <- search_tweets(Lookup, n = 6000,include_rts = FALSE, type = "recent", max_id = tweets, lang = "en", fileEncoding = "UTF-8", retryonratelimit = TRUE)

# #pulls more tweets on same look up from prior to last tweet pulled from previous call USEFUL IF PREVIOUS CALL EXCEEDED THE LIMITATION
# tweets3 <- search_tweets(Lookup, n = 3000,include_rts = FALSE, type = "recent", max_id = tweets2, lang = "en", fileEncoding = "UTF-8",retryonratelimit = TRUE)

#Joins the three lists together
tweets_join <- full_join(tweets,tweets2)
#tweets_join <- full_join(tweets_join,tweets3)
#creates a file in working repository for easy to access storage, Eventually I will add access code to a database instead
write_csv(tweets_join, file = "file.csv")

#Cleans text to single word and counts frequency
strippedTweets <-cleaned.text(tweets_join)


#Call garbage collector to help system memory
gc()
#########################################################################################################################################################
#########################################################################################################################################################
 

 #Creating a time-series graph that shows tweets over time based on creation date of tweets extracted

  #turning list into Data frame
  tweets.df <- as.data.frame(tweets_join)
  
  #adding a new column to round the time of creation to the nearest hour for easier aggregation
  tweets.df %<>%
    mutate(created = created_at %>% str_remove_all(pattern = '\\+0000') %>% 
             parse_date_time(orders = '%y-%m-%d %H%M%S'))
  
  tweets.df%<>%
        mutate(Created_At_Round = created %>% round(units = 'hours') %>% as.POSIXct())
  
  #finding the earliest post's creation time for the start of the chart
  tweets.df %>% 
    pull(created) %>% min()
  
  #finding the most recent creation time for the end of the chart
  tweets.df %>% 
    pull(created) %>% max()
  
  #Creating an object to store the linegraph and its variables in 
  lineGraphed <- tweets.df %>%
    count(Created_At_Round) %>%
    ggplot(aes(x = Created_At_Round, y = n)) +
    theme_light() + 
    geom_line() +
    labs(x= "Date", y = NULL)
   # geom_smooth(method = lm, se = FALSE, color = "gray", size = 1)
  #transforms ggplot line graph into interactive line graph
  ggplotly(lineGraphed, tooltip = "all", dynamicTicks = TRUE)%>%
    #Since the layout() function only has a title (and not subtitle) argument, we have to use some HTML to format our text to get it just right.
    layout(title = paste(
      '<b> </b> ',paste("Tweets Per Hour", paste("for Keyword", Lookup)),
      '<br><sup>',
      paste0(format(min(tweets.df$created_at), "%d %B %Y"), " to ", format(max(tweets.df$created_at),"%d %B %Y")),
      '</i><br>',
      '</sup>'
    ),
  margin = list(t = 75)
  )
  
  #Call garbage collector to help system memory
  gc()
#########################################################################################################################################################
#########################################################################################################################################################  
 
  
  #Intakes lexicon of positive and negative words for comparison in following code lines
  
   #imports positive and negative words 
  positive = scan('posSentiment.txt', what = 'character', comment.char = ';')
  negative = scan('negSentiment.txt', what = 'character', comment.char = ';')
  # add your list of words below as you wish if missing in above read lists
  pos.words = c(positive,'upgrade','Congrats','prizes','prize','thanks','thnx',
                'Grt','gr8','plz','trending','recovering','brainstorm','leader', 'congrats')
  neg.words = c(negative,'wtf','epicfail','Fight','fighting', 'arrest')
  
  
#########################################################################################################################################################  
#########################################################################################################################################################  
  
  
  #variable that holds the column 'full_text' (we dont technically need this if we pass tweet.df$full_text through the function)
  test <- tweets.df$full_text
  
  #new variable to determine the sentiment score based on how many positive or negative words are in the text
  analysis <- score.sentiment(test, pos.words, neg.words)
  
  # sentiment score frequency table displays data in a table
  table(analysis$score)

  #Barchart to display frequency by sentiment
  neutral <- length(which(analysis$score == 0))
  positive <- length(which(analysis$score > 0))
  negative <- length(which(analysis$score < 0))
  Sentiment <- c("Negative","Neutral","Positive")
  Count <- c(negative,neutral,positive)
  output <- data.frame(Sentiment,Count)
  output$Sentiment<-factor(output$Sentiment,levels=Sentiment)
  sentimentFreq <- ggplot(output, aes(x=Sentiment,y=Count))+
    geom_bar(stat = "identity", aes(fill = Sentiment))+
    ggtitle("Barchart of Sentiment type of Extracted tweets")
  ggplotly(sentimentFreq,tooltip = "all", dynamicTicks = TRUE)
  
  #Call garbage collector to help system memory
  gc()
#########################################################################################################################################################  
#########################################################################################################################################################    
  
  #Sets up color for sentiment
  play<-analysis
  play$Color <- replace(play$Color, play$score <0, Sentiment[1] )
  play$Color <- replace(play$Color, play$score >0, Sentiment[3] )
  play$Color <- replace(play$Color, play$score==0, Sentiment[2] )
  
  #histogram plot into object
  practice <- play %>%
    ggplot(aes(x = score, fill = Color)) + 
    geom_histogram( binwidth = 1)+ 
    scale_x_continuous()+
    ylab("Frequency") + 
    xlab("Sentiment score") +
    ggtitle("Distribution of Sentiment scores") +
    ggeasy::easy_center_title()
  #create interactive plot using histogram object
  ggplotly(practice, tooltip = "all", dynamicTicks = TRUE)
  
  
  #Call garbage collector to help system memory
  gc()
#########################################################################################################################################################
#########################################################################################################################################################    

  
  #Creates a word cloud of 100 words sized by frequency
  #adds positive and negative logical columns to help identify words
  
 strippedTweets$PosSentiment <- ifelse(match(strippedTweets$word, pos.words, nomatch = NA),Sentiment[3],F)
 strippedTweets$NegSentiment <- ifelse(match(strippedTweets$word, neg.words, nomatch = NA),Sentiment[1],F)
 strippedTweets$NeuSentiment <- ifelse((is.na(strippedTweets$PosSentiment) & is.na(strippedTweets$NegSentiment)),Sentiment[2],NA)
  
 strippedTweets <-  strippedTweets%>%
   mutate(Color = coalesce(PosSentiment, NegSentiment, NeuSentiment))%>%
   select(-PosSentiment, -NegSentiment,-NeuSentiment)
  
  words<- strippedTweets %>% 
    with(wordcloud(word, n, scale = c(2.2,.8), random.order = F, max.words = 100, color =brewer.pal(8, "Dark2"), random.color = TRUE))
  
  #Call garbage collector to help system memory
  gc()
#########################################################################################################################################################  
#########################################################################################################################################################

  
  #extracts emojis and creates a frequency chart for the top 15
emoji<-  tweets %>%
    mutate(emoji = emoji_extract_all(text)) %>%
    unnest(cols = c(emoji)) %>%
    count(emoji, sort = TRUE) %>%
    top_n(15)
  
  emo <-ggplot(emoji, aes(x=reorder(emoji, n), y=n)) + 
    geom_bar(stat="identity") +
    xlab("Terms") + 
    ylab("Count") + 
    theme_dark() +
    coord_flip() +
    theme(axis.text=element_text(size=10)) +
    ggtitle('Most common Emoji frequency plot') + geom_text(aes(label = n), colour = "white")+
    ggeasy::easy_center_title() 
  
  ggplotly(emo, tooltip = "all")

  #Call garbage collector to help system memory
  gc()
#########################################################################################################################################################  
#########################################################################################################################################################
 
  
   #Creates a horizontal frequency chart of top twenty words
     #Grabs top 10 positive words from tweets
    PosTweets <- strippedTweets%>%
      filter(Color == 'Positive')%>%
      top_n(10,n)
    
    #Grabs top 10 negative words from tweets
    NegTweets <- strippedTweets%>%
      filter(Color == 'Negative')%>%
      top_n(10,n)%>%
      #turns count values negative so the barchart has inverted variables 
      mutate(n = n*-1)
    
    #join the two tables for top twenty positive and negative tweets
    topTwenty <- full_join(PosTweets, NegTweets)
    
    #add a column which specifices color to positive and negative values (Sentiment vector assigns color to logical sentiment value)
    npgraph <- topTwenty%>%
      mutate(Color = ifelse((topTwenty$n > 0), Sentiment[3], Sentiment[1]))
    
    #Builds sorted vertical bar chart (currently has a positive and negative y axis)
    PosNeg<- ggplot(npgraph, aes(x=reorder(word, n), y=n, fill = Color) ) +  
    geom_bar(stat = "identity") +
      #this turns the labels on the y axis by adding the abs function to labels (however the bars label is still negative)
    scale_y_continuous(labels = abs)+
    xlab("Terms") + 
    ylab("Count") + 
    coord_flip() +
    theme_dark() +
    ggtitle('Top Ten Positive and Negative Words') + 
      #The bars change to positive because the abs function makes all values of n positive
    geom_text(aes(label = abs(n)), colour = "white") +
    ggeasy::easy_center_title()
    
    #creates an interactive chart with ggplot if you pass ggplot object as a parameter
    ggplotly(PosNeg)

    #Call garbage collector to help system memory
    gc()
#########################################################################################################################################################
#########################################################################################################################################################
    
    
#Creates chart to display Most popular hashtags associated with the original search term 
  pullHashtag <- tweets %>% 
    unnest_tokens(hashtag, text, "tweets", to_lower = FALSE) %>%
    filter(str_detect(hashtag, "^#"),
           hashtag != paste("#",Lookup)) %>%
    count(hashtag, sort = TRUE) %>%
    top_n(11)
  
  hashtag<- ggplot(pullHashtag, aes(x=reorder(hashtag, n), y=n)) + 
    geom_bar(stat="identity") +
    xlab("Terms") + 
    ylab("Count") + 
    coord_flip() +
    theme_dark() +
    theme(axis.text=element_text(size=10)) +
    ggtitle('Most common hashtag frequency plot') +
    ggeasy::easy_center_title() + geom_text(aes(label = n), colour = "white")
  ggplotly(hashtag, tooltip = "all")
  
  #Call garbage collector to help system memory
  gc()
  
  
  
  
  
  
#########################################################################################################################################################
#########################################################################################################################################################
  
  # ####NOT PART OF THE PROJECT JUST A TEST TO SEE HOW BIGRAMS WORK IN TEXT ANALYSIS
  # ####Trying to understand the process of machine learning and how to predict words that follow the preceding word
  # #bigram
  # bi.gram.words <- tweets.df %>%
  #   unnest_tokens(
  #     input = text,
  #     output = bigram,
  #     token = 'ngrams',
  #     n = 2
  #   ) %>%
  #   filter(! is.na(bigram))
  #
  # bi.gram.words %>%
  #   select(bigram) %>%
  #   head(10)
  #
  # extra.stop.words <- c('https')
  # stopwords.df <- tibble(
  #   word = c(stopwords(kind = 'es'),
  #            stopwords(kind = 'en'),
  #            extra.stop.words)
  # )
  # bi.gram.words %<>%
  #   separate(col = bigram, into = c('word1', 'word2'), sep = ' ') %>%
  #   filter(! word1 %in% stopwords.df$word) %>%
  #   filter(! word2 %in% stopwords.df$word) %>%
  #   filter(! is.na(word1)) %>%
  #   filter(! is.na(word2))
  # bi.gram.count <- bi.gram.words %>%
  #   dplyr::count(word1, word2, sort = TRUE) %>%
  #   dplyr::rename(weight = n)
  # bi.gram.count %>% head()
  #
  # bi.gram.count %>%
  #   ggplot(mapping = aes(x = weight)) +
  #   theme_light() +
  #   geom_histogram() +
  #   labs(title = "Bigram Weight Distribution")
  #
  # bi.gram.count %>%
  #   mutate(weight = log(weight + 1)) %>%
  #   ggplot(mapping = aes(x = weight)) +
  #   theme_light() +
  #   geom_histogram() +
  #   labs(title = "Bigram log-Weight Distribution")
  #
  # threshold <- 50
  #
  # # For visualization purposes we scale by a global factor.
  # ScaleWeight <- function(x, lambda) {
  #   x / lambda
  # }
  #
  # network <-  bi.gram.count %>%
  #   filter(weight > threshold) %>%
  #   mutate(weight = ScaleWeight(x = weight, lambda = 2E3)) %>%
  #   graph_from_data_frame(directed = FALSE)
  #
  # plot(
  #   network,
  #   vertex.size = 1,
  #   vertex.label.color = 'black',
  #   vertex.label.cex = 0.7,
  #   vertex.label.dist = 1,
  #   edge.color = 'gray',
  #   main = 'Bigram Count Network',
  #   sub = glue('Weight Threshold: {threshold}'),
  #   alpha = 50
  # )
  #
  # V(network)$degree <- strength(graph = network)
  #
  # # Compute the weight shares.
  # E(network)$width <- E(network)$weight/max(E(network)$weight)
  #
  # plot(
  #   network,
  #   vertex.color = 'lightblue',
  #   # Scale node size by degree.
  #   vertex.size = 2*V(network)$degree,
  #   vertex.label.color = 'black',
  #   vertex.label.cex = 0.6,
  #   vertex.label.dist = 1.6,
  #   edge.color = 'gray',
  #   # Set edge width proportional to the weight relative value.
  #   edge.width = 3*E(network)$width ,
  #   main = 'Bigram Count Network',
  #   sub = glue('Weight Threshold: {threshold}'),
  #   alpha = 50)
  #
  #
  # threshold <- 50
  #
  # network <-  bi.gram.count %>%
  #   filter(weight > threshold) %>%
  #   graph_from_data_frame(directed = FALSE)
  #
  # # Store the degree.
  # V(network)$degree <- strength(graph = network)
  # # Compute the weight shares.
  # E(network)$width <- E(network)$weight/max(E(network)$weight)
  #
  # # Create networkD3 object.
  # network.D3 <- igraph_to_networkD3(g = network)
  # # Define node size.
  # network.D3$nodes %<>% mutate(Degree = (1E-2)*V(network)$degree)
  # # Define color group
  # network.D3$nodes %<>% mutate(Group = 1)
  # # Define edges width.
  # network.D3$links$Width <- 10*E(network)$width
  #
  # forceNetwork(
  #   Links = network.D3$links,
  #   Nodes = network.D3$nodes,
  #   Source = 'source',
  #   Target = 'target',
  #   NodeID = 'name',
  #   Group = 'Group',
  #   opacity = 0.9,
  #   Value = 'Width',
  #   Nodesize = 'Degree',
  #   # We input a JavaScript function.
  #   linkWidth = JS("function(d) { return Math.sqrt(d.value); }"),
  #   fontSize = 12,
  #   zoom = TRUE,
  #   opacityNoHover = 1
  # )
  # #save.image(file = "SaveGlobalEnvironment.RData")

   warnings()
  #
  #